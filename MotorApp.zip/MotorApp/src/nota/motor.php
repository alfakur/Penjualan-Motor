<?php

include "config/koneksi.php";

?>

<!DOCTYPE html>
<html>
<head>
	<title>Laporan Stock Motor</title>
</head>
<body>
	<form method="post">
		<table align="center">
			<tr>
				<td>
					<div class="mainutama">
						<table align="center">
							<tr>
								<td width="7%" rowspan="3" align="center" valign="top"></td>
       						<td width="93%" valign="bottom">&nbsp;Laporan Stock Motor</td>
							</tr>
							<tr>
								<td colspan="2"align="center">localhost:3306</td>
							</tr>
						</table>
						<table width="100%">
						<tr><td><hr></td></tr>
					</table>
					<table align="center" border="1">
						<tr>
							<th>NO ID</th>
							<th>Jenis Motor</th>
							<th>Harga</th>
                            <th>Stock</th>


					
						</tr>
						<?php
					      @$sql = "SELECT * FROM jenis_motor";
					      @$query = mysqli_query($con, $sql);
					      while($data = mysqli_fetch_array($query)){
					    ?>
					    <tr>
					        <td align="center"><?= $data['kd_jenis'] ?></td>
					        <td><?= $data['jenis_motor'] ?></td>
					        <td><?= $data['harga'] ?></td>
					        <td></td>
					      </tr>
					      <?php } ?>
					</table>
					<table width="100%">
			      		<tr><td><hr></td></tr>
			    	</table> 
			    	<table align="center">
			      		<tr>
			        	<td>&copy; <?php echo date('Y'); ?></td>
			      		</tr>
			    	</table>
					</div>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>