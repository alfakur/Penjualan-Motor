<?php

include "config/koneksi.php";

?>

<!DOCTYPE html>
<html>
<head>
	<title font-size="50%">Laporan Pelanggan</title>
</head>
<body>
	<form method="post">
		<table align="center">
			<tr>
				<td>
					<div class="mainutama">
						<table align="center">
							<tr>
								<td width="7%" rowspan="3" align="center" valign="top"></td>
       						<td width="93%" valign="bottom">&nbsp;Laporan Pelanggan</td>
							</tr>
							<tr>
								<td colspan="2">localhost:3306</td>
							</tr>
						</table>
						<table width="100%">
						<tr><td><hr></td></tr>
					</table>
					<table align="center" border="1">
						<tr>
							<th bgcolor="#blue">No ID</th>
							<th bgcolor="#blue">Nama</th>
							<th bgcolor="#blue">No Telepon</th>
							<th bgcolor="#blue">Alamat</th>
				
					
						</tr>
						<?php
					      @$sql = "SELECT * FROM pelanggan";
					      @$query = mysqli_query($con, $sql);
					      while($data = mysqli_fetch_array($query)){
					    ?>
					    <tr>
					        <td align="center"><?= $data['id_pelanggan'] ?></td>
					        <td><?= $data['nama_pelanggan'] ?></td>
					        <td><?= $data['telp'] ?></td>
					        <td><?= $data['alamat'] ?></td>
					      </tr>
					      <?php } ?>
					</table>
					<table width="100%">
			      		<tr><td><hr></td></tr>
			    	</table> 
			    	<table align="center">
			      		<tr>
			        	<td>&copy; <?php echo date('Y'); ?></td>
			      		</tr>
			    	</table>
					</div>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>