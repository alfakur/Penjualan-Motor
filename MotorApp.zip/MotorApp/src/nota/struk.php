<?php 
include "config/koneksi.php";
?>
<form method="post">
<table border="1" align="center">
  <tr>
    <td>
      <div class="utama">
		<table align="center">
      		<tr>
        		<td width="0%" rowspan="0" align="justify-center" valign="top"></td>
        		<td width="100%" valign="top" align="center">&nbsp;<b>CV. SEJAHTERA ABADI</b></td>
      		</tr>
      		<tr>
       			<td valign="top" align="center">&nbsp;localhost:3306</td>
      		</tr>
    	</table>
    	<table width="100%">
      	<tr><td><hr></td></tr>
    	</table>
  		<table cellspacing="0" align="center">  
  		<?php @$sql = "SELECT * FROM transaksi INNER JOIN penerimaan USING(no_order) where no_transaksi = '$_GET[id]'";
		      $query = mysqli_query($con,$sql);
		      $row = mysqli_fetch_array($query)	
		 ?>
		<tr>
			<td>Nama      </td><td>: </td><td> &nbsp;<?php echo $row['nama_pelanggan']?></td>
		</tr>
		<tr>
      		<td>Tanggal Pembayaran     </td><td>: </td><td> &nbsp;<?php echo $row['tgl_masuk']; ?></td>
     	</tr>
      	<tr>
      		<td>Total Biaya </td><td>: </td><td> &nbsp;Rp.<?php echo $row['t_bayar']; ?></td>
      	</tr>
        <tr>
          <td>Bayar </td><td>: </td><td> &nbsp;Rp.<?php $a = $row['bayar']; $b = $row['dibayar']; echo $a + $b; ?></td>
        </tr>
        <tr>
          <td>Kembalian </td><td>: </td><td> &nbsp;Rp.<?php echo $row['kembalian']; ?></td>
        </tr>
    	<table  width="100%">
      		<tr><td><hr></td></tr>
      		<tr><td><center>TERIMA KASIH</center><hr></td></tr>
    	</table>
    	<table align="center">
      		<tr>
        		<td>&copy; <?php echo date('Y'); ?> LSP</td>
      		</tr>
    	</table>
	</div>
    </td>
  </tr>
</table>
</form>


<script type="text/javascript">
  window.onload=function(){
  window.print();
}
</script> 