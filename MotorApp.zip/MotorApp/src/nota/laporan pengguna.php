<?php

include "config/koneksi.php";

?>

<!DOCTYPE html>
<html>
<head>
	<title>Laporan Pengguna Aplikasi</title>
</head>
<body>
	<form method="post">
		<table align="center">
			<tr>
				<td>
					<div class="mainutama">
						<table align="center">
							<tr>
								<td width="7%" rowspan="3" align="center" valign="top"></td>
       						<td width="93%" valign="bottom">&nbsp;Laporan Pengguna Aplikasi</td>
							</tr>
							<tr>
								<td colspan="2">localhost:3306</td>
							</tr>
						</table>
						<table width="100%">
						<tr><td><hr></td></tr>
					</table>
					<table align="center" border="1">
						<tr>
		
							<th bgcolor="#grey">ID</th>
							<th bgcolor="#grey">Username</th>
							<th bgcolor="#grey">Nama Lengkap</th>
							<th bgcolor="#grey">Hak Akses</th>
							<th bgcolor="#grey">Keterangan</th>
					
						</tr>
						<?php
					      @$sql = "SELECT * FROM pengguna";
					      @$query = mysqli_query($con, $sql);
					      while($data = mysqli_fetch_array($query)){
					    ?>
					    <tr>
					        <td align="center"><?= $data['id_pengguna'] ?></td>
					        <td><?= $data['username'] ?></td>
					        <td><?= $data['nama_pengguna'] ?></td>
					        <td><?= $data['hakakses'] ?></td>
					      </tr>
					      <?php } ?>
					</table>
					<table width="100%">
			      		<tr><td><hr></td></tr>
			    	</table> 
			    	<table align="center">
			      		<tr>
			        	<td>&copy; <?php echo date('Y'); ?></td>
			      		</tr>
			    	</table>
					</div>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>